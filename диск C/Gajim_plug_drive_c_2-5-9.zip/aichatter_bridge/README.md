# AI Chatter Bridge for Gajim — Stage 2.5.6

Stable folder name: `aichatter_bridge`.

Adds event-driven bot status indicators without timers:

- 🟢 online = matching bot tab is open in Chrome CDP.
- 🟡 offline = matching tab is not found.
- Status refresh happens only on panel refresh, `.status` / `.bots`, and before routing a new task.
- No periodic polling / timers.
- Checked-but-offline bots are skipped silently by default.
- `.status` shows current bot online/offline state.

Checkboxes:
- still control default addressing / target selection;
- serve as the visual bot focus/filter layer conceptually;
- do not delete or rewrite history.

Commands:
- `.status`
- `.bots`
- `.results`
- `.deliver`
- `.queue`
- `.version`
- `.ping`

Chrome CDP URL defaults to:

```text
http://127.0.0.1:9222
```

Install:
unpack this ZIP to your Gajim plugins folder so that you have:

```text
%APPDATA%\Gajim\Plugins\aichatter_bridge
```


## Stage 2.5.7

Fixes bot status UI:
- no emoji indicators, because GTK/Gajim may render them as tofu boxes;
- use plain text status: `● online` / `● offline`;
- checkbox remains the user visual filter and default addressing control;
- status indicator is informational and not a checkbox.


## Stage 2.5.8

Fixes the compact panel layout:
- one checkbox per bot only;
- checkbox = visual layer + default addressing;
- status is a non-clickable colored dot:
  - green dot = online
  - yellow dot = offline
- no emoji indicators.


## Stage 2.5.9

Adds event-driven executor launch:
- after a task is queued, the plugin launches `ai_chatter_run_once.py`;
- no polling/timer loop is used;
- default command targets `G:\AI_chatter\ai_chatter_executor\ai_chatter_run_once.py`;
- executor output is written to `ai_chatter_event_executor.log` in the plugin local data folder;
- final delivery remains manual via `.deliver`.


## Stage 2.5.9-C

Temporary C-drive preset build.

Defaults:
- Python: `C:\Users\789\AppData\Local\Programs\Python\Python314\python.exe`
- Executor workdir: `C:\AI_chatter\ai_chatter_executor`
- Executor command:
  `C:\Users\789\AppData\Local\Programs\Python\Python314\python.exe C:\AI_chatter\ai_chatter_executor\ai_chatter_run_once.py --queue "{queue}" --max-tasks 1 --max-jobs 1 --timeout-ms 60000`

Install this build when AI Chatter is located at `C:\AI_chatter` under Windows user `789`.
