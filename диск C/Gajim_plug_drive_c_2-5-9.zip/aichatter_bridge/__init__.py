# SPDX-License-Identifier: GPL-3.0-or-later
"""AI Chatter Bridge plugin for Gajim.

Stage 2.5.9-C-C event-driven autorun C-drive
- injects a compact AI bot panel into the right side of the active chat window;
- keeps settings window as fallback;
- keeps text commands for mobile clients / diagnostics;
- adds event-driven online/offline bot status by Chrome CDP;
- skips offline bots silently when creating tasks.
"""

from __future__ import annotations

import json
import logging
import subprocess
import urllib.request
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from gi.repository import GLib
from gi.repository import Gtk

from gajim.common import app
from gajim.common import ged
from gajim.common.modules.contacts import BareContact
from gajim.common.modules.contacts import GroupchatContact
from gajim.common.modules.contacts import GroupchatParticipant
from gajim.common.structs import OutgoingMessage
from gajim.plugins.gajimplugin import GajimPlugin

log = logging.getLogger("gajim.p.aichatter_bridge")


class AIChatterBridgePlugin(GajimPlugin):
    config_default_values = {
        "room_jid": ("kuhetaje@chat.yax.im", "Main shared MUC room"),
        "respond_only_in_room": (False, "Respond only in the configured room"),
        "routing_enabled": (True, "Route normal user messages to active bots"),
        "routing_echo_enabled": (True, "Echo routing decisions to the room"),
        "route_any_non_command_in_room": (True, "Route non-command messages even if Gajim does not mark them as outgoing"),
        "queue_enabled": (True, "Write routed tasks to a JSONL queue"),
        "queue_file_name": ("ai_chatter_tasks.jsonl", "Task queue JSONL file name"),
        "results_file_name": ("ai_chatter_results.jsonl", "Result JSONL file name"),
        "result_delivery_batch_size": (3, "Maximum results to deliver per .deliver command"),
        "chrome_cdp_url": ("http://127.0.0.1:9222", "Chrome DevTools Protocol URL for online/offline status"),
        "offline_behavior": ("silent", "How to handle checked but offline bots: silent/notice"),
        "auto_run_executor": (True, "Launch ai_chatter_run_once.py automatically after queuing a task"),
        "executor_command": (
            'C:\\Users\\789\\AppData\\Local\\Programs\\Python\\Python314\\python.exe C:\\AI_chatter\\ai_chatter_executor\\ai_chatter_run_once.py --queue "{queue}" --max-tasks 1 --max-jobs 1 --timeout-ms 60000',
            "Command template for event-driven executor launch. Supports {queue}, {plugin_dir}, {local_dir}",
        ),
        "executor_workdir": ("C:\AI_chatter\ai_chatter_executor", "Executor working directory"),
        "executor_log_file_name": ("ai_chatter_event_executor.log", "Log file for event-driven executor launch"),
        "always_show_me": (True, "Always show user's own messages"),
        "hidden_bots_can_notify": (True, "Hidden bots may show priority notifications"),
        "priority_markers_text": (
            "DONE, NEED_USER, ERROR, IMPORTANT, REPORT",
            "Markers that bypass visibility filters",
        ),
        "free_bot_conversation": (True, "Bots may talk to each other"),
        "only_within_active_task": (True, "Bots talk only within active tasks"),
        "max_bot_only_turns": (6, "Max bot-only turns before cooldown"),
        "active_bot_ids_text": ("chatgpt,qwen,deepseek", "Visible/target bot ids"),
        "can_speak_bot_ids_text": ("chatgpt,qwen,deepseek", "Bots allowed to speak"),
        "chat_panel_enabled": (True, "Show compact AI panel in chat window"),
        "stage": ("stage_2_5_3_manual_results", "Internal plugin stage"),
    }

    def init(self) -> None:
        self._profiles: dict[str, Any] = {}
        self._bots: list[dict[str, str]] = []
        self._settings_window: Gtk.Window | None = None

        self._panel_box: Gtk.Box | None = None
        self._injected_box: Gtk.Box | None = None
        self._original_roster: Gtk.Widget | None = None
        self._paned: Gtk.Paned | None = None

        self.config_dialog = self._show_config_dialog
        self.events_handlers = {
            "message-received": (ged.POSTGUI, self._on_message_event),
            "message-sent": (ged.POSTGUI, self._on_message_event),
        }

    def activate(self) -> None:
        self._load_profiles()
        self._bots = self._build_bot_registry(self._profiles)
        self._ensure_defaults()
        self._update_bot_statuses()
        self.config["stage"] = "stage_2_5_9_c_event_driven_autorun_c_drive"
        self.save_config()
        GLib.idle_add(self._inject_chat_panel)
        log.warning("AI Chatter Bridge Stage 2.5.9-C-C event-driven autorun C-drive")

    def deactivate(self) -> None:
        self._remove_chat_panel()
        if self._settings_window is not None:
            self._settings_window.close()
            self._settings_window = None
        log.warning("AI Chatter Bridge deactivated")

    def _ensure_defaults(self) -> None:
        if not self._string_list_config("active_bot_ids_text"):
            self.config["active_bot_ids_text"] = ",".join(bot["id"] for bot in self._bots)
        if not self._string_list_config("can_speak_bot_ids_text"):
            self.config["can_speak_bot_ids_text"] = ",".join(bot["id"] for bot in self._bots)

    def _load_profiles(self) -> None:
        path = Path(self.local_file_path("ai_chatter_profiles.json"))
        try:
            self._profiles = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            log.exception("Could not load AI Chatter profiles from %s", path)
            self._profiles = {}

    def _build_bot_registry(self, profiles: dict[str, Any]) -> list[dict[str, str]]:
        bots: list[dict[str, str]] = []
        for profile_key, profile in profiles.items():
            if not profile.get("enabled", True):
                continue
            chat_id = str(profile.get("chatId") or profile_key.split("::", 1)[0])
            title = str(profile.get("chatName") or profile.get("profileName") or chat_id)
            origin = str(profile.get("origin", ""))
            adapter = str(profile.get("runtime", {}).get("adapter", chat_id))
            bots.append({
                "id": chat_id,
                "title": title,
                "profileKey": str(profile_key),
                "origin": origin,
                "adapter": adapter,
                "status": "configured",
            })
        return bots

    def _bot_ids(self) -> list[str]:
        if not self._bots:
            self._load_profiles()
            self._bots = self._build_bot_registry(self._profiles)
        return [bot["id"] for bot in self._bots]

    def _bot_title(self, bot_id: str) -> str:
        for bot in self._bots:
            if bot["id"] == bot_id:
                return bot["title"]
        return bot_id

    def _string_list_config(self, key: str) -> list[str]:
        value = self.config[key]
        if isinstance(value, str):
            return [item.strip() for item in value.split(",") if item.strip()]
        if isinstance(value, list):
            return [str(item) for item in value]
        return []

    def _set_string_list_config(self, key: str, values: list[str]) -> None:
        known = set(self._bot_ids())
        filtered = [v for v in values if v in known]
        self.config[key] = ",".join(filtered)

    def _bot_profile(self, bot_id: str) -> dict[str, Any]:
        for profile in self._profiles.values():
            if not isinstance(profile, dict):
                continue
            if str(profile.get("chatId", "")).lower() == bot_id.lower():
                return profile
        return {}

    def _cdp_pages(self) -> list[dict[str, Any]]:
        url = str(self.config["chrome_cdp_url"]).rstrip("/") + "/json/list"
        try:
            with urllib.request.urlopen(url, timeout=1.5) as response:
                data = json.loads(response.read().decode("utf-8", errors="replace"))
        except Exception:
            return []
        if not isinstance(data, list):
            return []
        return [item for item in data if isinstance(item, dict)]

    def _bot_online_statuses(self) -> dict[str, str]:
        """Return bot online/offline by checking open CDP tabs.

        No timers are used. This is called only on panel refresh, .status/.bots,
        and before routing a new task.
        """
        if not self._profiles:
            self._load_profiles()

        pages = self._cdp_pages()
        page_urls = [
            str(page.get("url", "")).lower()
            for page in pages
            if str(page.get("type", "")) == "page"
        ]

        statuses: dict[str, str] = {}
        for bot_id in self._bot_ids():
            profile = self._bot_profile(bot_id)
            origin = str(profile.get("origin", "")).lower().rstrip("/")
            url_match = str(profile.get("urlMatch", "")).lower().replace("*", "").rstrip("/")
            needles = [value for value in (origin, url_match) if value]

            online = False
            for page_url in page_urls:
                if any(needle and page_url.startswith(needle) for needle in needles):
                    online = True
                    break

            statuses[bot_id] = "online" if online else "offline"

        return statuses

    def _update_bot_statuses(self) -> dict[str, str]:
        statuses = self._bot_online_statuses()
        for bot in self._bots:
            bot["status"] = statuses.get(bot["id"], "offline")
        return statuses

    def _status_text(self, bot: dict[str, str]) -> str:
        if bot.get("status") == "online":
            return "●"
        return "●"

    def _status_tooltip(self, bot: dict[str, str]) -> str:
        if bot.get("status") == "online":
            return "online: вкладка бота открыта в CDP Chrome"
        return "offline: подходящая вкладка не найдена в CDP Chrome"

    def _status_markup(self, bot: dict[str, str]) -> str:
        if bot.get("status") == "online":
            return '<span foreground="#30d158">●</span>'
        return '<span foreground="#ffd60a">●</span>'

    # ------------------------------------------------------------------
    # Right-side chat panel
    # ------------------------------------------------------------------
    def _inject_chat_panel(self) -> bool:
        if not bool(self.config["chat_panel_enabled"]):
            return False

        try:
            control = app.window.get_control()
            paned = control._ui.conv_view_paned
            roster = control.get_group_chat_roster()

            # Already injected
            if self._injected_box is not None:
                return False

            self._paned = paned
            self._original_roster = roster

            panel = self._build_compact_panel()
            panel.set_margin_top(8)
            panel.set_margin_bottom(8)
            panel.set_margin_start(8)
            panel.set_margin_end(8)

            wrapper = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
            wrapper.set_size_request(245, -1)

            # Detach roster from paned before placing it into wrapper.
            paned.set_end_child(None)
            wrapper.append(panel)
            wrapper.append(roster)
            paned.set_end_child(wrapper)

            self._panel_box = panel
            self._injected_box = wrapper
            return False
        except Exception:
            log.exception("Could not inject AI Chatter panel into chat window")
            return False

    def _remove_chat_panel(self) -> None:
        try:
            if self._paned is not None and self._original_roster is not None:
                self._paned.set_end_child(None)
                self._paned.set_end_child(self._original_roster)
        except Exception:
            log.exception("Could not restore original Gajim roster panel")
        finally:
            self._panel_box = None
            self._injected_box = None
            self._original_roster = None
            self._paned = None

    def _build_compact_panel(self) -> Gtk.Box:
        self._load_profiles()
        self._bots = self._build_bot_registry(self._profiles)
        self._ensure_defaults()
        self._update_bot_statuses()

        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        box.add_css_class("card")

        title_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        box.append(title_row)

        title = Gtk.Label(label="AI Chatter")
        title.set_xalign(0)
        title.set_hexpand(True)
        title.add_css_class("heading")
        title_row.append(title)

        refresh = Gtk.Button(label="↻")
        refresh.set_tooltip_text("Обновить статус и панель")
        title_row.append(refresh)

        hint = Gtk.Label(label="✓ видно/адресую   ● online/offline")
        hint.set_xalign(0)
        hint.add_css_class("caption")
        box.append(hint)

        list_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        box.append(list_box)

        active_ids = set(self._string_list_config("active_bot_ids_text"))

        for bot in self._bots:
            row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
            row.set_hexpand(True)

            toggle = Gtk.CheckButton()
            toggle.set_active(bot["id"] in active_ids)
            toggle.set_tooltip_text("Показать слой этого бота и адресовать ему мои новые сообщения")
            row.append(toggle)

            status = Gtk.Label()
            try:
                status.set_markup(self._status_markup(bot))
            except Exception:
                status.set_text("●")
            status.set_tooltip_text(self._status_tooltip(bot))
            row.append(status)

            name = Gtk.Label(label=bot["title"])
            name.set_xalign(0)
            name.set_hexpand(True)
            name.set_tooltip_text(self._status_tooltip(bot))
            row.append(name)

            def on_toggle_toggled(check: Gtk.CheckButton, bot_id: str = bot["id"]) -> None:
                ids = set(self._string_list_config("active_bot_ids_text"))
                if check.get_active():
                    ids.add(bot_id)
                else:
                    ids.discard(bot_id)

                # One checkbox is now the source of truth for both visual focus
                # and default addressing. Keep the legacy can_speak field in sync
                # so older routing code keeps working.
                sorted_ids = sorted(ids)
                self._set_string_list_config("active_bot_ids_text", sorted_ids)
                self._set_string_list_config("can_speak_bot_ids_text", sorted_ids)
                self.save_config()

            toggle.connect("toggled", on_toggle_toggled)
            list_box.append(row)

        quick = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
        box.append(quick)

        all_button = Gtk.Button(label="Все")
        none_button = Gtk.Button(label="Никого")
        quick.append(all_button)
        quick.append(none_button)

        def set_all(active: bool) -> None:
            ids = self._bot_ids() if active else []
            self._set_string_list_config("active_bot_ids_text", ids)
            self._set_string_list_config("can_speak_bot_ids_text", ids)
            self.save_config()
            self._refresh_panel()

        all_button.connect("clicked", lambda _b: set_all(True))
        none_button.connect("clicked", lambda _b: set_all(False))
        refresh.connect("clicked", lambda _b: self._refresh_panel())

        return box

    def _refresh_panel(self) -> None:
        if self._injected_box is None:
            GLib.idle_add(self._inject_chat_panel)
            return

        try:
            wrapper = self._injected_box
            old_panel = self._panel_box
            if old_panel is not None:
                wrapper.remove(old_panel)
            panel = self._build_compact_panel()
            panel.set_margin_top(8)
            panel.set_margin_bottom(8)
            panel.set_margin_start(8)
            panel.set_margin_end(8)
            wrapper.prepend(panel)
            self._panel_box = panel
        except Exception:
            log.exception("Could not refresh AI Chatter panel")

    # ------------------------------------------------------------------
    # Message routing and commands
    # ------------------------------------------------------------------
    def _normalize_jid(self, jid: object) -> str:
        text = str(jid).strip()
        if text.startswith("xmpp:"):
            text = text[5:]
        if "/" in text:
            text = text.split("/", 1)[0]
        return text.lower()

    def _event_text(self, event: object) -> str:
        try:
            message = event.message
            text = getattr(message, "text", None)
            if text is None:
                return ""
            return str(text).strip()
        except Exception:
            log.exception("Could not read event message text")
            return ""

    def _is_outgoing_event(self, event: object) -> bool:
        try:
            message = event.message
            direction = str(getattr(message, "direction", "")).lower()
            return "out" in direction or "sent" in direction
        except Exception:
            return False

    def _on_message_event(self, event: object) -> None:
        try:
            if getattr(event, "from_mam", False):
                return

            text = self._event_text(event)
            if not text:
                return
            if text.startswith("AI Chatter Bridge:"):
                return

            event_jid = self._normalize_jid(getattr(event, "jid", ""))
            configured_room = self._normalize_jid(self.config["room_jid"])
            if bool(self.config["respond_only_in_room"]) and event_jid != configured_room:
                return

            if self._looks_like_command(text):
                response = self._handle_command(text)
                if response:
                    account = str(getattr(event, "account", ""))
                    self._send_reply(account, event_jid, response)
                return

            # Safety: no dot/bang-prefixed service-like message can enter the AI task queue.
            if self._is_service_like_message(text):
                account = str(getattr(event, "account", ""))
                self._send_reply(
                    account,
                    event_jid,
                    "AI Chatter Bridge: служебная команда не распознана и не поставлена в очередь. Используйте .help",
                )
                return

            if bool(self.config["routing_enabled"]):
                # Some Gajim 2.4.x events do not expose direction in the way we expected.
                # Commands work, but normal outgoing user text may not be marked as outgoing.
                # For the configured bot-room workflow, lenient mode treats ordinary
                # non-command messages in the room as user tasks. Bridge-generated replies
                # are still ignored above by the "AI Chatter Bridge:" guard.
                if self._is_outgoing_event(event) or bool(self.config["route_any_non_command_in_room"]):
                    account = str(getattr(event, "account", ""))
                    self._simulate_routing(account, event_jid, text)
        except Exception:
            log.exception("AI Chatter Bridge message handling failed")

    def _is_service_like_message(self, text: str) -> bool:
        lines = [line.strip() for line in str(text).splitlines() if line.strip()]
        if not lines:
            return False
        return lines[0].startswith(".") or lines[0].startswith("!")

    def _looks_like_command(self, text: str) -> bool:
        lines = [line.strip() for line in str(text).splitlines() if line.strip()]
        if not lines:
            return False
        first = lines[0].lower()
        if first.startswith("."):
            first = "!" + first[1:]
        cmd = first.split(maxsplit=1)[0]
        return cmd in {
            "!ping", "!bots", "!room", "!config", "!help", "!aichatter",
            "!show", "!speak", "!all", "!only", "!mute", "!unmute",
            "!routing", "!queue", "!results", "!deliver", "!version", "!status",
        }

    def _canonical_command(self, text: str) -> str:
        lines = [line.strip() for line in str(text).splitlines() if line.strip()]
        if not lines:
            return ""
        text = lines[0]
        if text.startswith("."):
            return "!" + text[1:]
        return text

    def _parse_bot_args(self, text: str) -> list[str]:
        parts = text.split(maxsplit=1)
        if len(parts) < 2:
            return []
        raw = parts[1].replace(";", ",").replace(" ", ",")
        return [item.strip().lower() for item in raw.split(",") if item.strip()]

    def _handle_command(self, text: str) -> str | None:
        cmd = self._canonical_command(text)
        cmd_l = cmd.lower()

        if cmd_l == "!ping":
            return (
                "AI Chatter Bridge: активен.\n"
                f"Комната в настройках: {self.config['room_jid']}\n"
                "Stage 2.5.9-C-C event-driven autorun C-drive"
            )

        if cmd_l == "!room":
            return f"AI Chatter Bridge: основная конференция — {self.config['room_jid']}"

        if cmd_l == "!bots":
            return self._format_bots()

        if cmd_l == "!status":
            return self._format_status()

        if cmd_l == "!config":
            return self._format_config()

        if cmd_l in ("!help", "!aichatter"):
            return (
                "AI Chatter Bridge: команды диагностики\n"
                ".ping — проверка активности\n"
                ".bots — список ботов\n.status — online/offline по открытым вкладкам Chrome CDP\n"
                ".room — основная конференция\n"
                ".config — сводка настроек\n"
                ".only chatgpt / .all / .mute deepseek — fallback для мобильного клиента\n"
                "В Gajim основное управление через AI-панель справа. Executor запускается по событию новой задачи, если auto-run включён."
            )

        if cmd_l.startswith("!show"):
            bots = self._parse_bot_args(cmd)
            if not bots:
                return "AI Chatter Bridge: укажите ботов, например .show chatgpt,qwen"
            self._set_string_list_config("active_bot_ids_text", bots)
            self.save_config()
            self._refresh_panel()
            return f"AI Chatter Bridge: адресовать — {self.config['active_bot_ids_text']}"

        if cmd_l.startswith("!speak"):
            bots = self._parse_bot_args(cmd)
            if not bots:
                return "AI Chatter Bridge: укажите ботов, например .speak chatgpt,qwen"
            self._set_string_list_config("can_speak_bot_ids_text", bots)
            self.save_config()
            self._refresh_panel()
            return f"AI Chatter Bridge: могут говорить — {self.config['can_speak_bot_ids_text']}"

        if cmd_l.startswith("!only"):
            bots = self._parse_bot_args(cmd)
            if len(bots) != 1:
                return "AI Chatter Bridge: укажите одного бота, например .only chatgpt"
            self._set_string_list_config("active_bot_ids_text", bots)
            self._set_string_list_config("can_speak_bot_ids_text", bots)
            self.save_config()
            self._refresh_panel()
            return f"AI Chatter Bridge: режим беседы только с {bots[0]}"

        if cmd_l in ("!all",):
            all_ids = self._bot_ids()
            self._set_string_list_config("active_bot_ids_text", all_ids)
            self._set_string_list_config("can_speak_bot_ids_text", all_ids)
            self.save_config()
            self._refresh_panel()
            return "AI Chatter Bridge: включены все боты."

        if cmd_l.startswith("!mute"):
            bots = set(self._parse_bot_args(cmd))
            current = [b for b in self._string_list_config("can_speak_bot_ids_text") if b not in bots]
            self._set_string_list_config("can_speak_bot_ids_text", current)
            self.save_config()
            self._refresh_panel()
            return f"AI Chatter Bridge: могут говорить — {self.config['can_speak_bot_ids_text']}"

        if cmd_l.startswith("!unmute"):
            bots = self._parse_bot_args(cmd)
            current = set(self._string_list_config("can_speak_bot_ids_text"))
            current.update(bots)
            self._set_string_list_config("can_speak_bot_ids_text", sorted(current))
            self.save_config()
            self._refresh_panel()
            return f"AI Chatter Bridge: могут говорить — {self.config['can_speak_bot_ids_text']}"

        if cmd_l in ("!version",):
            return "AI Chatter Bridge: Stage 2.5.9-C-C event-driven autorun C-drive"

        if cmd_l in ("!queue",):
            return (
                "AI Chatter Bridge: очередь задач\n"
                f"- включена: {self.config['queue_enabled']}\n"
                f"- файл: {self._queue_path()}"
            )

        if cmd_l in ("!results",):
            total, delivered, pending = self._result_counts()
            return (
                "AI Chatter Bridge: результаты\n"
                "- режим: ручная доставка, без таймера\n"
                f"- файл: {self._results_path()}\n"
                f"- всего результатов: {total}\n"
                f"- уже доставлено: {delivered}\n"
                f"- ожидают доставки: {pending}\n"
                f"- размер пачки .deliver: {self.config['result_delivery_batch_size']}"
            )

        if cmd_l in ("!deliver",):
            count = self._deliver_results_once()
            total, delivered, pending = self._result_counts()
            return (
                "AI Chatter Bridge: доставка результатов выполнена.\n"
                f"- доставлено сейчас: {count}\n"
                f"- осталось недоставленных: {pending}"
            )

        if cmd_l.startswith("!routing"):
            parts = cmd_l.split()
            if len(parts) < 2 or parts[1] not in ("on", "off"):
                return f"AI Chatter Bridge: routing сейчас {self.config['routing_enabled']}. Используйте .routing on/off"
            self.config["routing_enabled"] = parts[1] == "on"
            self.save_config()
            return f"AI Chatter Bridge: routing = {self.config['routing_enabled']}"

        return None

    def _format_bots(self) -> str:
        self._load_profiles()
        self._bots = self._build_bot_registry(self._profiles)
        if not self._bots:
            return "AI Chatter Bridge: профили ботов не найдены."

        statuses = self._update_bot_statuses()
        visible = set(self._string_list_config("active_bot_ids_text"))
        can_speak = set(self._string_list_config("can_speak_bot_ids_text"))

        lines = ["AI Chatter Bridge: боты из профилей:"]
        for bot in self._bots:
            flags = []
            flags.append("адресуется" if bot["id"] in visible else "не адресуется")
            flags.append("говорит" if bot["id"] in can_speak else "молчит")
            status = statuses.get(bot["id"], "offline")
            icon = "●" if status == "online" else "●"
            lines.append(
                f'- {icon} {bot["title"]} ({bot["id"]}) — {", ".join(flags)}; '
                f'status={status}; profile={bot["profileKey"]}'
            )
        return "\n".join(lines)

    def _format_status(self) -> str:
        self._load_profiles()
        self._bots = self._build_bot_registry(self._profiles)
        statuses = self._update_bot_statuses()
        lines = ["AI Chatter Bridge: статус ботов"]
        for bot in self._bots:
            status = statuses.get(bot["id"], "offline")
            icon = "●" if status == "online" else "●"
            lines.append(f'- {icon} {bot["title"]} ({bot["id"]}) — {status}')
        return "\n".join(lines)

    def _format_config(self) -> str:
        return (
            "AI Chatter Bridge: настройки\n"
            f"- конференция: {self.config['room_jid']}\n"
            f"- routing обычных сообщений: {self.config['routing_enabled']}\n"
            f"- мягкое распознавание обычного текста: {self.config['route_any_non_command_in_room']}\n"
            f"- адресовать: {self.config['active_bot_ids_text']}\n"
            f"- могут говорить: {self.config['can_speak_bot_ids_text']}\n"
            f"- скрытые уведомления: {self.config['hidden_bots_can_notify']}\n"
            f"- приоритетные маркеры: {self.config['priority_markers_text']}\n"
            f"- боты общаются между собой: {self.config['free_bot_conversation']}\n"
            f"- только по активным задачам: {self.config['only_within_active_task']}\n"
            f"- лимит сообщений ботов подряд: {self.config['max_bot_only_turns']}\n"
            f"- CDP status URL: {self.config['chrome_cdp_url']}\n"
            f"- offline behavior: {self.config['offline_behavior']}\n"
            f"- auto-run executor: {self.config['auto_run_executor']}\n"
            f"- executor command: {self.config['executor_command']}"
        )

    def _target_bot_ids(self) -> list[str]:
        visible = set(self._string_list_config("active_bot_ids_text"))
        can_speak = set(self._string_list_config("can_speak_bot_ids_text"))
        statuses = self._update_bot_statuses()
        known = self._bot_ids()
        return [
            bot_id
            for bot_id in known
            if bot_id in visible
            and bot_id in can_speak
            and statuses.get(bot_id) == "online"
        ]

    def _checked_target_bot_ids(self) -> list[str]:
        visible = set(self._string_list_config("active_bot_ids_text"))
        can_speak = set(self._string_list_config("can_speak_bot_ids_text"))
        known = self._bot_ids()
        return [bot_id for bot_id in known if bot_id in visible and bot_id in can_speak]


    def _executor_log_path(self) -> Path:
        name = str(self.config["executor_log_file_name"]).strip() or "ai_chatter_event_executor.log"
        return Path(self.local_file_path(name))

    def _format_executor_command(self) -> str:
        command = str(self.config["executor_command"]).strip()
        queue = str(self._queue_path())
        local_dir = str(Path(self.local_file_path("")).parent)
        plugin_dir = local_dir
        return (
            command
            .replace("{queue}", queue)
            .replace("{plugin_dir}", plugin_dir)
            .replace("{local_dir}", local_dir)
        )

    def _trigger_executor_async(self) -> None:
        if not bool(self.config["auto_run_executor"]):
            return

        command = self._format_executor_command()
        if not command:
            return

        workdir_text = str(self.config["executor_workdir"]).strip()
        workdir = Path(workdir_text) if workdir_text else None

        try:
            log_path = self._executor_log_path()
            log_path.parent.mkdir(parents=True, exist_ok=True)
            with log_path.open("a", encoding="utf-8", errors="replace") as log_file:
                log_file.write("\n=== AI Chatter event executor launch ===\n")
                log_file.write(f"command: {command}\n")
                log_file.write(f"workdir: {workdir or ''}\n")

                subprocess.Popen(
                    command,
                    cwd=str(workdir) if workdir else None,
                    shell=True,
                    stdout=log_file,
                    stderr=subprocess.STDOUT,
                )

            log.warning("AI Chatter event-driven executor launched: %s", command)
        except Exception:
            log.exception("Could not launch AI Chatter event-driven executor")

    def _queue_path(self) -> Path:
        name = str(self.config["queue_file_name"]).strip() or "ai_chatter_tasks.jsonl"
        return Path(self.local_file_path(name))

    def _append_task(self, *, account: str, jid: str, text: str, targets: list[str]) -> dict[str, object]:
        task = {
            "id": str(uuid.uuid4()),
            "createdAt": datetime.now(timezone.utc).isoformat(),
            "status": "queued",
            "source": {
                "type": "gajim",
                "account": account,
                "roomJid": jid,
            },
            "targets": [
                {
                    "botId": bot_id,
                    "botTitle": self._bot_title(bot_id),
                }
                for bot_id in targets
            ],
            "message": {
                "text": text,
            },
            "routing": {
                "activeBotIds": self._string_list_config("active_bot_ids_text"),
                "canSpeakBotIds": self._string_list_config("can_speak_bot_ids_text"),
            },
        }

        queue_path = self._queue_path()
        queue_path.parent.mkdir(parents=True, exist_ok=True)
        with queue_path.open("a", encoding="utf-8") as file:
            file.write(json.dumps(task, ensure_ascii=False) + "\n")
        return task

    def _simulate_routing(self, account: str, jid: str, text: str) -> None:
        checked_targets = self._checked_target_bot_ids()
        targets = self._target_bot_ids()
        if not targets:
            # If bots are checked but offline, default behavior is silent:
            # the panel status indicators show ● offline and no bot-specific
            # OFFLINE messages are added to the chat.
            if checked_targets and str(self.config["offline_behavior"]).lower() == "silent":
                return

            if bool(self.config["routing_echo_enabled"]):
                message = "AI Chatter Bridge: не выбран ни один bot-адресат. Поставьте галочку в AI-панели справа или используйте .only/.all."
                if checked_targets:
                    message = "AI Chatter Bridge: выбранные боты сейчас offline. Откройте вкладку бота в CDP Chrome или нажмите ↻ в панели."
                self._send_reply(account, jid, message)
            return

        task: dict[str, object] | None = None
        queue_error = ""
        if bool(self.config["queue_enabled"]):
            try:
                task = self._append_task(account=account, jid=jid, text=text, targets=targets)
                self._trigger_executor_async()
            except Exception as error:
                queue_error = str(error)
                log.exception("Could not append AI Chatter task")

        if not bool(self.config["routing_echo_enabled"]):
            return

        names = ", ".join(self._bot_title(bot_id) for bot_id in targets)
        preview = text.replace("\n", " ").strip()
        if len(preview) > 180:
            preview = preview[:177] + "..."

        if task is not None:
            task_id = str(task["id"])
            queue_path = str(self._queue_path())
            reply = (
                "AI Chatter Bridge: задача поставлена в очередь.\n"
                f"ID: {task_id}\n"
                f"Кому: {names}\n"
                f"Файл очереди: {queue_path}\n"
                f"Текст: {preview}\n"
                "Исполнитель Python/Chrome запущен автоматически по событию новой задачи." if bool(self.config["auto_run_executor"]) else "Следующий этап — исполнитель Python/Chrome будет читать эту очередь и отправлять задачи в AI-чаты."
            )
        elif queue_error:
            reply = (
                "AI Chatter Bridge: задача маршрутизирована, но не записана в очередь.\n"
                f"Кому: {names}\n"
                f"Ошибка очереди: {queue_error}\n"
                f"Текст: {preview}"
            )
        else:
            reply = (
                "AI Chatter Bridge: задача принята в тестовую маршрутизацию.\n"
                f"Кому уйдёт дальше: {names}\n"
                f"Текст: {preview}\n"
                "Очередь задач выключена в настройках."
            )

        self._send_reply(account, jid, reply)

    def _results_path(self) -> Path:
        name = str(self.config["results_file_name"]).strip() or "ai_chatter_results.jsonl"
        return Path(self.local_file_path(name))

    def _delivered_state_path(self) -> Path:
        return Path(self.local_file_path("ai_chatter_delivered_results.json"))

    def _read_delivered_result_ids(self) -> set[str]:
        path = self._delivered_state_path()
        if not path.exists():
            return set()
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            return set()
        if not isinstance(data, dict):
            return set()
        items = data.get("deliveredResultIds", [])
        if not isinstance(items, list):
            return set()
        return {str(item) for item in items}

    def _write_delivered_result_ids(self, delivered: set[str]) -> None:
        path = self._delivered_state_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "deliveredResultIds": sorted(delivered),
            "updatedAt": datetime.now(timezone.utc).isoformat(),
        }
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    def _read_results_jsonl(self) -> list[dict[str, object]]:
        path = self._results_path()
        if not path.exists():
            return []
        rows: list[dict[str, object]] = []
        try:
            with path.open("r", encoding="utf-8") as file:
                for line_no, line in enumerate(file, start=1):
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        item = json.loads(line)
                    except Exception:
                        log.warning("Invalid AI Chatter result JSON at line %s", line_no)
                        continue
                    if isinstance(item, dict):
                        rows.append(item)
        except Exception:
            log.exception("Could not read AI Chatter results")
        return rows

    def _result_counts(self) -> tuple[int, int, int]:
        delivered_ids = self._read_delivered_result_ids()
        total = 0
        pending = 0
        for result in self._read_results_jsonl():
            result_id = str(result.get("id", ""))
            status = str(result.get("status", ""))
            if not result_id or status not in ("done", "error"):
                continue
            total += 1
            if result_id not in delivered_ids:
                pending += 1
        return total, len(delivered_ids), pending

    def _deliver_results_once(self, max_results: int | None = None) -> int:
        delivered_count = 0
        try:
            if max_results is None:
                try:
                    max_results = int(self.config["result_delivery_batch_size"])
                except Exception:
                    max_results = 3

            if max_results < 1:
                max_results = 1
            if max_results > 10:
                max_results = 10

            delivered = self._read_delivered_result_ids()
            changed = False

            for result in self._read_results_jsonl():
                if delivered_count >= max_results:
                    break

                result_id = str(result.get("id", ""))
                if not result_id or result_id in delivered:
                    continue

                status = str(result.get("status", ""))
                if status not in ("done", "error"):
                    continue

                source = result.get("source", {})
                if not isinstance(source, dict):
                    source = {}

                account = str(source.get("account", ""))
                room_jid = str(source.get("roomJid") or self.config["room_jid"])
                bot_title = str(result.get("botTitle") or result.get("botId") or "Bot")

                if status == "done":
                    answer = str(result.get("answer", "")).strip()
                    if not answer:
                        answer = "(пустой ответ)"
                    message = f"{bot_title} [RESULT]:\n{answer}"
                else:
                    error = str(result.get("error", "unknown error"))
                    message = f"{bot_title} [ERROR]: {error}"

                ok = self._send_reply(account, self._normalize_jid(room_jid), message)
                if ok:
                    delivered.add(result_id)
                    delivered_count += 1
                    changed = True

            if changed:
                self._write_delivered_result_ids(delivered)

        except Exception:
            log.exception("AI Chatter manual result delivery failed")

        return delivered_count

    def _resolve_contact(self, client: object, jid: str) -> object | None:
        contacts = client.get_module("Contacts")
        try:
            contact = contacts.get_contact(jid, groupchat=True)
            if contact is not None:
                return contact
        except Exception:
            pass
        try:
            return contacts.get_contact(jid, groupchat=False)
        except Exception:
            return None

    def _send_reply(self, account: str, jid: str, message: str) -> bool:
        if not account or not jid or not message:
            return False
        if not app.account_is_available(account):
            log.warning("Account is not available: %s", account)
            return False

        client = app.get_client(account)
        contact = self._resolve_contact(client, jid)
        if contact is None:
            log.warning("Could not resolve contact for %s", jid)
            return False

        if isinstance(contact, GroupchatContact) and not contact.is_joined:
            log.warning("Groupchat is not joined: %s", jid)
            return False

        if not isinstance(contact, (BareContact, GroupchatContact, GroupchatParticipant)):
            log.warning("Unsupported contact type for reply: %s", type(contact))
            return False

        outgoing = OutgoingMessage(account=account, contact=contact, text=message)
        client.send_message(outgoing)
        return True

    # ------------------------------------------------------------------
    # Settings window remains as fallback
    # ------------------------------------------------------------------
    def _show_config_dialog(self, parent: Gtk.Window | None = None) -> None:
        if self._settings_window is not None:
            self._settings_window.present()
            return

        win = Gtk.Window(title="AI Chatter Bridge — настройки")
        win.set_default_size(560, 420)
        if parent is not None:
            win.set_transient_for(parent)

        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        box.set_margin_top(16)
        box.set_margin_bottom(16)
        box.set_margin_start(16)
        box.set_margin_end(16)
        win.set_child(box)

        title = Gtk.Label(label="AI Chatter Bridge")
        title.set_xalign(0)
        title.add_css_class("title-1")
        box.append(title)

        room_entry = Gtk.Entry()
        room_entry.set_text(str(self.config["room_jid"]))
        room_entry.set_placeholder_text("kuhetaje@chat.yax.im")
        box.append(Gtk.Label(label="JID конференции"))
        box.append(room_entry)

        panel_enabled = Gtk.CheckButton(label="Показывать AI-панель справа в окне чата")
        panel_enabled.set_active(bool(self.config["chat_panel_enabled"]))
        box.append(panel_enabled)

        routing_echo = Gtk.CheckButton(label="Показывать отчёт о тестовой маршрутизации в чат")
        routing_echo.set_active(bool(self.config["routing_echo_enabled"]))
        box.append(routing_echo)

        route_any = Gtk.CheckButton(label="Считать обычный текст в комнате задачей, даже если Gajim не пометил его как исходящий")
        route_any.set_active(bool(self.config["route_any_non_command_in_room"]))
        box.append(route_any)

        queue_enabled = Gtk.CheckButton(label="Записывать задачи в JSONL-очередь")
        queue_enabled.set_active(bool(self.config["queue_enabled"]))
        box.append(queue_enabled)

        queue_name_entry = Gtk.Entry()
        queue_name_entry.set_text(str(self.config["queue_file_name"]))
        queue_name_entry.set_placeholder_text("ai_chatter_tasks.jsonl")
        box.append(Gtk.Label(label="Файл очереди"))
        box.append(queue_name_entry)

        cdp_entry = Gtk.Entry()
        cdp_entry.set_text(str(self.config["chrome_cdp_url"]))
        cdp_entry.set_placeholder_text("http://127.0.0.1:9222")
        box.append(Gtk.Label(label="Chrome CDP URL для online/offline статуса"))
        box.append(cdp_entry)

        auto_run = Gtk.CheckButton(label="Автоматически запускать executor после новой задачи")
        auto_run.set_active(bool(self.config["auto_run_executor"]))
        box.append(auto_run)

        executor_command_entry = Gtk.Entry()
        executor_command_entry.set_text(str(self.config["executor_command"]))
        executor_command_entry.set_placeholder_text('C:\\Users\\789\\AppData\\Local\\Programs\\Python\\Python314\\python.exe C:\\AI_chatter\\ai_chatter_executor\\ai_chatter_run_once.py --queue "{queue}" --max-tasks 1 --max-jobs 1 --timeout-ms 60000')
        box.append(Gtk.Label(label="Команда executor"))
        box.append(executor_command_entry)

        executor_workdir_entry = Gtk.Entry()
        executor_workdir_entry.set_text(str(self.config["executor_workdir"]))
        executor_workdir_entry.set_placeholder_text("C:\\AI_chatter\\ai_chatter_executor")
        box.append(Gtk.Label(label="Рабочая папка executor"))
        box.append(executor_workdir_entry)

        info = Gtk.Label(
            label=(
                "Основное управление — в AI-панели справа в окне чата. "
                "Текстовые команды сохранены для мобильных клиентов: .ping, .bots, .only, .all, .mute."
            )
        )
        info.set_wrap(True)
        info.set_xalign(0)
        box.append(info)

        actions = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        actions.set_halign(Gtk.Align.END)
        box.append(actions)

        save_button = Gtk.Button(label="Сохранить")
        close_button = Gtk.Button(label="Закрыть")
        save_button.add_css_class("suggested-action")
        actions.append(save_button)
        actions.append(close_button)

        def save_settings(_button: Gtk.Button) -> None:
            self.config["room_jid"] = room_entry.get_text().strip()
            self.config["chat_panel_enabled"] = panel_enabled.get_active()
            self.config["routing_echo_enabled"] = routing_echo.get_active()
            self.config["route_any_non_command_in_room"] = route_any.get_active()
            self.config["queue_enabled"] = queue_enabled.get_active()
            self.config["queue_file_name"] = queue_name_entry.get_text().strip() or "ai_chatter_tasks.jsonl"
            self.config["chrome_cdp_url"] = cdp_entry.get_text().strip() or "http://127.0.0.1:9222"
            self.config["auto_run_executor"] = auto_run.get_active()
            self.config["executor_command"] = executor_command_entry.get_text().strip()
            self.config["executor_workdir"] = executor_workdir_entry.get_text().strip()
            self.save_config()
            self._remove_chat_panel()
            if bool(self.config["chat_panel_enabled"]):
                GLib.idle_add(self._inject_chat_panel)

        def on_close(*_args: object) -> None:
            self._settings_window = None

        save_button.connect("clicked", save_settings)
        close_button.connect("clicked", lambda _button: win.close())
        win.connect("close-request", on_close)

        self._settings_window = win
        win.present()
